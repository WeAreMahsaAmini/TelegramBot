export interface SessionData {
  lastCelebrityId: string;
  messageCount: string;
}
