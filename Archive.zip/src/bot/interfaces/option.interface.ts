export interface Option {
  botToken: string;
}
