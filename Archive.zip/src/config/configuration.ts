export default () => ({
  welcomeMessage:
    'Welcome to the freedom way. We, are trying to remove the obstacles of this way together. ',
  bot: {
    token: process.env.BOT_TOKEN || '',
  },
});
