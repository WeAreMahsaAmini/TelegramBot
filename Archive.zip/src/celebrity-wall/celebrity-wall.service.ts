import { Injectable } from '@nestjs/common';
import { CTX } from 'src/bot/interfaces';
import { Telegraf } from 'telegraf';

@Injectable()
export class CelebrityWallService {
  bot: Telegraf = null;
  setBot(bot: Telegraf): void {
    this.bot = bot;
  }
  showCelebrities(ctx: CTX): any {
    //console.log(ctx.session?.lastCelebrityId);
    // this.bot.telegram.sendMessage(
    //   ctx.chat.id,
    //   ctx.session?.lastCelebrityId + 'The latest update list',
    //   {
    //     reply_markup: {
    //       inline_keyboard: [
    //         [{ text: 'Show me more', callback_data: 'show_more' }],
    //       ],
    //     },
    //   },
    // );
  }

  getList() {}
}
